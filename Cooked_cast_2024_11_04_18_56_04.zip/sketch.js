//Deadpool,16 anos, tema ação
//Espetacular Homem-aranha,10 anos,ficção cientifíca e ação
//Homem de ferro 1, 12 anos,ação ficção
//Filme Logan,17 anos,ação e aventura
//Guerra civil,12 anos,ação ficção cientifíca e aventura
//Capitão américa,12 anos,ação
//O incrivel Hulk,12 anos, ação e fantasia
//Thor:Ragnarok,12 anos, ação e fantasia
//Vingadores:Guerra infinita,12 anos,ação comédia e aventura
//Doutor estranho no multiverso da loucura,13 anos, fantasia
//Vingadores, 12 anos,ação e aventura

let campoIdade;
let campoFantasia;
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 12) {
      return "Espetacular Homem-aranha";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "Homem aranha: no aranhaverso";          
        } else{
         return "Capitão América";
        }
      } else {
        if (gostaDeFantasia) {
          return "Vingadores";
        } else {
          return "O incrível Hulk";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "Thor:Ragnarok";
    } else {
      return "Guerra cívil";
    }
  }
}
